import json
import pymysql
import os

# Database configuration from environment variables
DB_HOST = os.environ['DB_HOST']
DB_USER = os.environ['DB_USER']
DB_PASSWORD = os.environ['DB_PASSWORD']
DB_NAME = os.environ['DB_NAME']


# Connect to MySQL database
def connect_db():
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )


# Parsing functions
def can1andcan2(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    values = [int(hex_string[i:i + 4], 16) for i in range(0, len(hex_string), 4)]
    parsed_values = [(value - 16000) / 100 for value in values]
    return parsed_values


def can3(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    values = [int(hex_string[i:i + 4], 16) for i in range(0, len(hex_string), 4)]
    parsed_values = [
        (values[0] - 30000) / 10,
        (values[1] - 16000) / 100,
        (values[2] - 16000) / 100,
        (values[3] - 30000) / 10
    ]
    return parsed_values


def can4(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    values = [int(hex_string[i:i + 4], 16) for i in range(0, len(hex_string), 4)]
    last_two_bits = int(hex_string[-2:], 16)
    parsed_values = [
        values[0],
        (values[1] - 30000) / 10,
        (values[2] - 30000) / 10,
        int(hex_string[-4:-2], 16),
        0 if last_two_bits == 0 else 1
    ]
    return parsed_values


def can5(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    values = [int(hex_string[i:i + 2], 16) for i in range(0, len(hex_string), 2)]
    return values


def can6(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    values = [int(hex_string[i:i + 4], 16) for i in range(0, len(hex_string), 4)]
    parsed_values = [
        values[0] / 10,
        values[1] / 10,
        (values[2] - 30000) / 10,
        (values[3] - 30000) / 10
    ]
    return parsed_values


def can7(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    values = [int(hex_string[i:i + 4], 16) for i in range(0, len(hex_string) - 4, 4)]
    last_value = int(hex_string[-4:], 16)
    parsed_values = [
        values[0] / 1000,
        values[1] / 1000,
        int(hex_string[-8:-6], 16) - 40,
        int(hex_string[-6:-4], 16) - 40,
        last_value
    ]
    return parsed_values


def can8(hex_string):
    hex_string = hex_string[2:]  # Remove '0x' prefix
    return hex_string


def parse_payload(reported_data):
    formatted_data = reported_data.copy()  # Copy existing data

    if "902" in reported_data:
        hex_value = reported_data["902"]
        parsed_values = can1andcan2(hex_value)
        formatted_data.update({
            "temps1": parsed_values[0],
            "temps2": parsed_values[1],
            "temps3": parsed_values[2],
            "temps4": parsed_values[3]
        })

    if "903" in reported_data:
        hex_value2 = reported_data["903"]
        parsed_values2 = can1andcan2(hex_value2)
        formatted_data.update({
            "temps5": parsed_values2[0],
            "temps6": parsed_values2[1],
            "temps7": parsed_values2[2],
            "temps8": parsed_values2[3]
        })

    if "904" in reported_data:
        hex_value3 = reported_data["904"]
        parsed_values3 = can3(hex_value3)
        formatted_data.update({
            "boxtemp": parsed_values3[0],
            "dspres": parsed_values3[1],
            "sspres": parsed_values3[2],
            "compcurr": parsed_values3[3]
        })

    if "905" in reported_data:
        hex_value4 = reported_data["905"]
        parsed_values4 = can4(hex_value4)
        formatted_data.update({
            "comprpm": parsed_values4[0],
            "setpoint": parsed_values4[1],
            "ttd/ttc": parsed_values4[2],
            "hysteresis": parsed_values4[3],
            "dsbutton": parsed_values4[4]
        })

    if "906" in reported_data:
        hex_value5 = reported_data["906"]
        parsed_values5 = can5(hex_value5)
        formatted_data.update({
            "coolst": parsed_values5[0],
            "dfstate": parsed_values5[1],
            "drstate": parsed_values5[2],
            "stbyswitch": parsed_values5[3],
            "chstatus": parsed_values5[4],
            "chinterlock": parsed_values5[5],
            "errorstate": parsed_values5[6],
            "warningstate": parsed_values5[7]
        })

    if "907" in reported_data:
        hex_value6 = reported_data["907"]
        parsed_values6 = can6(hex_value6)
        formatted_data.update({
            "soc": parsed_values6[0],
            "voltage": parsed_values6[1],
            "current": parsed_values6[2],
            "soh": parsed_values6[3]
        })

    if "908" in reported_data:
        hex_value7 = reported_data["908"]
        parsed_values7 = can7(hex_value7)
        formatted_data.update({
            "maxcelvolt": parsed_values7[0],
            "mincelvolt": parsed_values7[1],
            "maxceltemp": parsed_values7[2],
            "minceltemp": parsed_values7[3],
            "ch/dischcycle": parsed_values7[4]
        })

    if "909" in reported_data:
        hex_value8 = reported_data["909"]
        parsed_values8 = can8(hex_value8)
        formatted_data["can8"] = parsed_values8

    return formatted_data


def lambda_handler(event, context):
    try:
        # Print event data for debugging
        print("Received event:", json.dumps(event))

        # Extract topic and clean it to form the table name

        # Extract data from the MQTT message
        reported_data = event["state"]["reported"]
        formatted_data = parse_payload(reported_data)
        table_name = formatted_data.get("14")
        print(table_name)

        # Database connection
        connection = connect_db()

        with connection.cursor() as cursor:
            # Dynamically construct SQL query
            sql = f"""
            INSERT INTO `yotuh{table_name}` (
                ts, pr, latlng, alt, ang, sat, sp, evt, ignitionst, movement, gsmsignal, sleepmode, gnssstatus, batterylevel, gnsspdop, gnsshdop, externalvolt, vehiclespeed, batvolt, batcurrent, axisxacc, axisyacc, axiszacc, actgsmoperator, tripodometer, totalodometer, dallastemp1, dallastemp1id, dallastemp2id, temps1, temps2, temps3, temps4, temps5, temps6, temps7, temps8,
                boxtemp, dspres, sspres, compcurr, comprpm, setpoint, ttd_ttc,
                hysteresis, dsbutton, coolst, dfstate, drstate, stbyswitch,
                chstatus, chinterlock, errorstate, warningstate, soc, voltage,
                current, soh, maxcelvolt, mincelvolt, maxceltemp, minceltemp,
                ch_dischcycle, can8
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,  
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,  
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,  
                %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,  
                %s, %s, %s, %s
            )
            """
            cursor.execute(sql, (
                formatted_data.get("ts"), formatted_data.get("pr"),
                formatted_data.get("latlng"), formatted_data.get("alt"),
                formatted_data.get("ang"), formatted_data.get("sat"),
                formatted_data.get("sp"), formatted_data.get("evt"),
                formatted_data.get("239"), formatted_data.get("240"),
                formatted_data.get("21"), formatted_data.get("200"),
                formatted_data.get("69"), formatted_data.get("113"),
                formatted_data.get("181"), formatted_data.get("182"),
                formatted_data.get("66"), formatted_data.get("24"),
                formatted_data.get("67"), formatted_data.get("68"),
                formatted_data.get("17"), formatted_data.get("18"),
                formatted_data.get("19"), formatted_data.get("241"),
                formatted_data.get("199"), formatted_data.get("16"),
                formatted_data.get("72"), formatted_data.get("76"),
                formatted_data.get("77"),
                formatted_data.get("temps1"), formatted_data.get("temps2"),
                formatted_data.get("temps3"), formatted_data.get("temps4"),
                formatted_data.get("temps5"), formatted_data.get("temps6"),
                formatted_data.get("temps7"), formatted_data.get("temps8"),
                formatted_data.get("boxtemp"), formatted_data.get("dspres"),
                formatted_data.get("sspres"), formatted_data.get("compcurr"),
                formatted_data.get("comprpm"), formatted_data.get("setpoint"),
                formatted_data.get("ttd/ttc"), formatted_data.get("hysteresis"),
                formatted_data.get("dsbutton"), formatted_data.get("coolst"),
                formatted_data.get("dfstate"), formatted_data.get("drstate"),
                formatted_data.get("stbyswitch"), formatted_data.get("chstatus"),
                formatted_data.get("chinterlock"), formatted_data.get("errorstate"),
                formatted_data.get("warningstate"), formatted_data.get("soc"),
                formatted_data.get("voltage"), formatted_data.get("current"),
                formatted_data.get("soh"), formatted_data.get("maxcelvolt"),
                formatted_data.get("mincelvolt"), formatted_data.get("maxceltemp"),
                formatted_data.get("minceltemp"), formatted_data.get("ch/dischcycle"),
                formatted_data.get("can8")
            ))

        # Commit the transaction
        connection.commit()

        return {
            'statusCode': 200,
            'body': json.dumps('Data inserted successfully')
        }

    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }