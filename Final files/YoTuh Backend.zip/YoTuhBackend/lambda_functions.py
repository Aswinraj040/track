import json
import pymysql
import os
import time
from datetime import datetime

# Database configuration from environment variables
DB_HOST = os.environ['DB_HOST']
DB_USER = os.environ['DB_USER']
DB_PASSWORD = os.environ['DB_PASSWORD']
DB_NAME = os.environ['DB_NAME']


def connect_db():
    return pymysql.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        cursorclass=pymysql.cursors.DictCursor
    )


# Login function
def login_user(body):
    try:
        username = body.get("username")
        password = body.get("password")

        if not username or not password:
            return response(400, {"success": False, "message": "Username and password required"})

        # Connect to DB
        connection = connect_db()
        with connection.cursor() as cursor:
            # Check if the username exists
            sql = "SELECT password FROM users WHERE username = %s"
            cursor.execute(sql, (username,))
            user = cursor.fetchone()

            if not user:
                return response(404, {"success": False, "message": "User not found"})  # Username does not exist

            # Validate password
            stored_password = user["password"]
            if password == stored_password:  # ⚠️ Plain-text password check (Consider using bcrypt for security)
                sql = "SELECT description , username FROM users WHERE username = %s"
                cursor.execute(sql, (username,))
                desc = cursor.fetchone()
                return response(200, {"success": True, "message": "Login successful", "description": desc})
            else:
                return response(401, {"success": False, "message": "Invalid credentials"})

    except Exception as e:
        return response(500, {"success": False, "message": str(e)})
    finally:
        connection.close()


def fetch_real_time_data(description_dict):
    result = {}
    try:
        connection = connect_db()
        with connection.cursor() as cursor:
            for key, value in description_dict.items():
                table_name = f"yotuh{key}"  # Table name format
                query = f"""
                    SELECT ts, latlng, alt, ang, boxtemp, soc , ttd_ttc, setpoint, drstate, errorstate, warningstate 
                    FROM {table_name} 
                    ORDER BY ts DESC 
                    LIMIT 1;
                """
                cursor.execute(query)
                row = cursor.fetchone()

                if row:
                    result[key] = row
                    print(f"Full row for {key}: {row}")  # Print full row
                    print(f"SOC for {key}: {row['soc']}")  # Print SOC value
                else:
                    result[key] = {"message": "No data found"}

        connection.close()
    except Exception as e:
        return {"success": False, "error": str(e)}

    return {"success": True, "data": result}


def fetch_historical_data(startdate, enddate, device_id):
    try:
        if not (startdate and enddate and device_id):
            return {"success": False, "message": "Missing required parameters: startdate, enddate, or id"}

        # Convert inputs to integer (since they are in milliseconds)
        start_ts = int(startdate)
        end_ts = int(enddate)

        # Establish database connection
        conn = connect_db()

        with conn.cursor() as cursor:
            # Construct table name dynamically
            table_name = f"yotuh{device_id}"
            query = f"""
                SELECT ts, latlng, soc, boxtemp, drstate 
                FROM `{table_name}` 
                WHERE ts BETWEEN %s AND %s
            """
            cursor.execute(query, (start_ts, end_ts))
            result = cursor.fetchall()

        conn.close()

        # Convert ts from Unix timestamp (milliseconds) to readable datetime
        for row in result:
            row["ts"] = datetime.utcfromtimestamp(int(row["ts"]) / 1000).strftime('%Y-%m-%d %H:%M:%S')

        return {"success": True, "data": result}

    except Exception as e:
        return {"success": False, "error": str(e)}


# Common response function with CORS headers
def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Access-Control-Allow-Origin": "*",  # Allow all origins
            "Access-Control-Allow-Methods": "OPTIONS, POST, GET",  # Allowed methods
            "Access-Control-Allow-Headers": "Content-Type, Authorization",  # Allowed headers
        },
        "body": json.dumps(body)
    }


column_mapping = {
    "Altitude": "alt",
    "Ignition status": "ignitionst",
    "Movement": "movement",
    "Gsm Signal": "gsmsignal",
    "Sleep mode": "sleepmode",
    "Gnss status": "gnssstatus",
    "Battery level": "batterylevel",
    "GNSS PDOP": "gnsspdop",
    "Total Odometer": "totalodometer",
    "GNSS HDOP": "gnsshdop",
    "Vehicle Speed": "vehiclespeed",
    "Battery Current": "batcurrent",
    "Temp sensor 1": "temps1",
    "Temp sensor 2": "temps2",
    "Temp sensor 3": "temps3",
    "Temp Sensor 4": "temps4",
    "Temp Sensor 5": "temps5",
    "Temp Sensor 6": "temps6",
    "Temp Sensor 7": "temps7",
    "Temp Sensor 8": "temps8",
    "Box Temperature": "boxtemp",
    "Discharge side pressure": "dspres",
    "Suction side pressure": "sspres",
    "Compression Current": "compcurr",
    "Compressor rpm": "comprpm",
    "Set point": "setpoint",
    "TTD/TTC": "ttd_ttc",
    "Hysteresis": "hysteresis",
    "Driver switch button": "dsbutton",
    "Cooling state": "coolst",
    "Defrost state": "dfstate",
    "Door state": "drstate",
    "Standby switch": "stbyswitch",
    "Charging status": "chstatus",
    "Charging interlock": "chinterlock",
    "Error state": "errorstate",
    "Warning state": "warningstate",
    "Soc": "soc",
    "Voltage": "voltage",
    "Current": "current",
    "Soh": "soh",
    "Max cell voltage": "maxcelvolt",
    "Min cell voltage": "mincelvolt",
    "Max cell temperature": "maxceltemp",
    "Min cell temperature": "minceltemp",
    "Charge / Discharge cycles": "ch_dischcycle"
}


def convert_date_to_epoch(date_str, is_start=True):
    """Convert date from dd/mm/yyyy to Unix Epoch timestamp."""
    try:
        if is_start:
            # Set time to 00:00:00 for start date
            dt = datetime.strptime(date_str, "%d/%m/%Y")
            dt = dt.replace(hour=0, minute=0, second=0)
        else:
            # Set time to 23:59:59 for end date
            dt = datetime.strptime(date_str, "%d/%m/%Y")
            dt = dt.replace(hour=23, minute=59, second=59)

        return int(time.mktime(dt.timetuple())) * 1000  # Convert to milliseconds
    except ValueError:
        raise ValueError(f"Invalid date format: {date_str}. Expected format: dd/mm/yyyy.")


def fetch_data_from_rds(table_name, columns, start_date, end_date):
    """Fetch records from RDS database."""
    try:
        # Connect to the database
        connection = connect_db()

        with connection.cursor() as cursor:
            # Ensure "ts" column is always included
            columns_with_ts = ["ts"] + columns
            columns_str = ", ".join(columns_with_ts)

            sql = f"""
                SELECT {columns_str} FROM `{table_name}`
                WHERE `ts` BETWEEN %s AND %s
                ORDER BY `ts` ASC;
            """

            # Execute the query
            cursor.execute(sql, (start_date, end_date))
            result = cursor.fetchall()
            for row in result:
                if "ts" in row:
                    row["ts"] = datetime.utcfromtimestamp(int(row["ts"]) / 1000).strftime("%d/%m/%Y %H:%M:%S")

        connection.close()
        return result

    except pymysql.MySQLError as e:
        return {"error": str(e)}


def create_user(data):
    try:
        username = data["username"]
        password = data["password"]
        description = json.dumps(data.get("description", {}))  # Convert dict to JSON string

        conn = connect_db()
        with conn.cursor() as cursor:
            # Check if user already exists
            cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
            existing_user = cursor.fetchone()

            if existing_user:
                return {"message": "User already exists. Please update instead."}

            # Insert new user
            sql = """
            INSERT INTO users (username, password, description)
            VALUES (%s, %s, %s);
            """
            cursor.execute(sql, (username, password, description))
            conn.commit()

            # Extract keys from description and create tables
            description_dict = json.loads(description)  # Convert back to dictionary
            for key in description_dict.keys():
                table_name = f"yotuh{key}"
                create_table_query = f"""
                CREATE TABLE IF NOT EXISTS `{table_name}` (
                    `ts` varchar(255) DEFAULT NULL,
                    `pr` int DEFAULT NULL,
                    `latlng` varchar(255) DEFAULT NULL,
                    `alt` float DEFAULT NULL,
                    `ang` float DEFAULT NULL,
                    `sat` int DEFAULT NULL,
                    `sp` float DEFAULT NULL,
                    `evt` varchar(255) DEFAULT NULL,
                    `ignitionst` tinyint(1) DEFAULT NULL,
                    `movement` tinyint(1) DEFAULT NULL,
                    `gsmsignal` int DEFAULT NULL,
                    `sleepmode` tinyint(1) DEFAULT NULL,
                    `gnssstatus` varchar(255) DEFAULT NULL,
                    `batterylevel` float DEFAULT NULL,
                    `gnsspdop` float DEFAULT NULL,
                    `gnsshdop` float DEFAULT NULL,
                    `externalvolt` float DEFAULT NULL,
                    `vehiclespeed` float DEFAULT NULL,
                    `batvolt` float DEFAULT NULL,
                    `batcurrent` float DEFAULT NULL,
                    `axisxacc` float DEFAULT NULL,
                    `axisyacc` float DEFAULT NULL,
                    `axiszacc` float DEFAULT NULL,
                    `actgsmoperator` varchar(255) DEFAULT NULL,
                    `tripodometer` float DEFAULT NULL,
                    `totalodometer` float DEFAULT NULL,
                    `dallastemp1` float DEFAULT NULL,
                    `dallastemp1id` varchar(255) DEFAULT NULL,
                    `dallastemp2id` varchar(255) DEFAULT NULL,
                    `temps1` float DEFAULT NULL,
                    `temps2` float DEFAULT NULL,
                    `temps3` float DEFAULT NULL,
                    `temps4` float DEFAULT NULL,
                    `temps5` float DEFAULT NULL,
                    `temps6` float DEFAULT NULL,
                    `temps7` float DEFAULT NULL,
                    `temps8` float DEFAULT NULL,
                    `boxtemp` float DEFAULT NULL,
                    `dspres` float DEFAULT NULL,
                    `sspres` float DEFAULT NULL,
                    `compcurr` float DEFAULT NULL,
                    `comprpm` float DEFAULT NULL,
                    `setpoint` float DEFAULT NULL,
                    `ttd_ttc` float DEFAULT NULL,
                    `hysteresis` float DEFAULT NULL,
                    `dsbutton` tinyint(1) DEFAULT NULL,
                    `coolst` varchar(255) DEFAULT NULL,
                    `dfstate` tinyint(1) DEFAULT NULL,
                    `drstate` tinyint(1) DEFAULT NULL,
                    `stbyswitch` tinyint(1) DEFAULT NULL,
                    `chstatus` varchar(255) DEFAULT NULL,
                    `chinterlock` tinyint(1) DEFAULT NULL,
                    `errorstate` varchar(255) DEFAULT NULL,
                    `warningstate` varchar(255) DEFAULT NULL,
                    `soc` float DEFAULT NULL,
                    `voltage` float DEFAULT NULL,
                    `current` float DEFAULT NULL,
                    `soh` float DEFAULT NULL,
                    `maxcelvolt` float DEFAULT NULL,
                    `mincelvolt` float DEFAULT NULL,
                    `maxceltemp` float DEFAULT NULL,
                    `minceltemp` float DEFAULT NULL,
                    `ch_dischcycle` int DEFAULT NULL,
                    `can8` varchar(255) DEFAULT NULL
                );
                """
                cursor.execute(create_table_query)

            conn.commit()
            return {"message": "User added successfully, and tables created"}

    except Exception as e:
        return {"message": str(e)}

    finally:
        conn.close()


# **Fetch Users**
def get_users():
    try:
        conn = connect_db()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users;")
            users = cursor.fetchall()

        return {"users": users}
    except Exception as e:
        return {"message": str(e)}
    finally:
        conn.close()


# **Delete User**
def delete_user(data):
    try:
        username = data["username"]

        conn = connect_db()
        with conn.cursor() as cursor:
            # Retrieve the description before deleting the user
            cursor.execute("SELECT description FROM users WHERE username = %s;", (username,))
            user_record = cursor.fetchone()
            print("User Record:", user_record)

            if not user_record:
                return {"message": "User not found"}

            description = user_record.get("description")  # Extract description from the fetched row
            print("Description:", description)
            if not description:
                return {"message": "Description not found for user"}

            try:
                description_dict = json.loads(description)  # Parse JSON string to dictionary
            except json.JSONDecodeError:
                return {"message": "Error parsing description"}

            # Delete the user from the users table
            cursor.execute("DELETE FROM users WHERE username = %s;", (username,))
            if cursor.rowcount == 0:
                return {"message": "User deletion failed"}

            # Delete tables based on the description keys
            deleted_tables = []
            for key in description_dict.keys():
                table_name = f"yotuh{key}"
                drop_table_query = f"DROP TABLE IF EXISTS `{table_name}`;"
                cursor.execute(drop_table_query)
                deleted_tables.append(table_name)

            conn.commit()
            return {
                "message": "User and associated tables deleted successfully",
                "deleted_tables": deleted_tables
            }

    except Exception as e:
        return {"message": f"Error: {str(e)}"}

    finally:
        conn.close()


def update_description(data):
    try:
        username = data.get("username")
        password = data.get("password")
        description = data.get("description")

        if not username or not password or not description:
            return {"message": "Missing required fields"}

        conn = connect_db()
        with conn.cursor() as cursor:
            sql = """
                UPDATE users
                SET password = %s, description = %s
                WHERE username = %s;
            """
            cursor.execute(sql, (password, description, username))
            conn.commit()

            if cursor.rowcount == 0:
                return {"message": "User not found or no update made"}

        return {"message": "User updated successfully"}

    except Exception as e:
        return {"message": str(e)}

    finally:
        conn.close()


def chartDataValue(data):
    try:
        device_id = data.get("id")
        start_date_str = data.get("startDate")
        end_date_str = data.get("endDate")
        items = data.get("items", [])

        if not device_id or not start_date_str or not end_date_str:
            return {"success": False, "message": "Missing required parameters"}

        start_date = int(start_date_str)
        end_date = int(end_date_str)

        # Map the item names using column_mapping
        mapped_items = [column_mapping.get(item, item) for item in items]

        # Construct table name dynamically
        table_name = f"yotuh{device_id}"

        # Fetch data from RDS
        data_from_rds = fetch_data_from_rds(table_name, mapped_items, start_date, end_date)

        return {"success": True, "data": data_from_rds}

    except Exception as e:
        return {"success": False, "message": str(e)}


# Handle OPTIONS requests for CORS preflight
def handle_options():
    return response(200, {})


def lambda_handler(event, context):
    try:
        # Handle OPTIONS request for CORS preflight
        if event.get("httpMethod") == "OPTIONS":
            return handle_options()

        body = json.loads(event.get("body", "{}"))
    except json.JSONDecodeError:
        return response(400, {"success": False, "message": "Invalid JSON"})

    # Route requests
    if body.get("action") == "login":
        return login_user(body)

    elif body.get("action") == "realTimeData":
        description_str = body.get("description", "{}")

        try:
            description_dict = json.loads(description_str)  # Convert string to dictionary
        except json.JSONDecodeError:
            return response(400, {"success": False, "message": "Invalid description format"})

        # Fetch data
        real_time_data = fetch_real_time_data(description_dict)
        return response(200, real_time_data)

    elif body.get("action") == "overview":
        startdate = body.get("startdate")
        enddate = body.get("enddate")
        device_id = body.get("id")

        # Fetch historical data from DB
        historical_data = fetch_historical_data(startdate, enddate, device_id)
        return response(200, historical_data)
    elif body.get("action") == "chartData":
        return response(200, chartDataValue(body))
    elif body.get("action") == "createUser":
        return response(200, create_user(body))
    elif body.get("action") == "getUsers":
        return response(200, get_users())
    elif body.get("action") == "deleteUser":
        return response(200, delete_user(body))
    elif body.get("action") == "updateDescription":
        return response(200, update_description(body))
    else:
        return response(404, {"success": False, "message": "Endpoint not found"})